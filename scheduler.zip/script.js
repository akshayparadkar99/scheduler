const form = document.getElementById('addTaskForm');
const list = document.getElementById('taskList');

form.addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('taskName').value;
  const time = document.getElementById('taskTime').value;
  const item = document.createElement('li');
  item.textContent = name + " — " + new Date(time).toLocaleString();
  list.appendChild(item);
  form.reset();
});
